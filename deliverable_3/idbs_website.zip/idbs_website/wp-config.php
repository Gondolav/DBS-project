<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ch264665_IDBS_project' );

/** MySQL database username */
define( 'DB_USER', 'ch264665_ElPrimo' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Vamonos1!' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'F[vVKJwtfRfYNa*`rfB%L.O*IB@Hr>}uVx~(E,fV dK^uWz#iQ,pMaI7T4<sbk]>' );
define( 'SECURE_AUTH_KEY',  'S[x5rq%S~+O?J(X/D Z`VJUO^#<C^pPN`Eg4zm:Gn2Wc|W%F8x$fm5Jl#N-rz<Q^' );
define( 'LOGGED_IN_KEY',    'pxRs[C@CPd2o{Pn>Vw~G#3z/il+x}H$T|z9hk~g`zodyrqj{e>rRUz3LzYlGh&y$' );
define( 'NONCE_KEY',        '<n%&nZuXu|k2;>FWYj|weXUJMPo+ft8ms7V$r=Js&O [g5mLq*/{Q{}bt#KDe_>_' );
define( 'AUTH_SALT',        ',1Br%IiW6;%om3U(v,qzSP|O=>3C]8B+]})J? `eyv,Ky6RM>06-|jqi,y}HF8B$' );
define( 'SECURE_AUTH_SALT', 'aT@b;t~F,7ldqt>E+;}!{!LB=X^zH]t9Kw@]=Kk3JNnUwj]MKnV-PUtoFiN1}.X#' );
define( 'LOGGED_IN_SALT',   '?de~*l?MsVJH^K}{:/=/G%:WGrF)lp)48ko^iXZd<?Rmk4SvyqIzSpU#7mbwltUr' );
define( 'NONCE_SALT',       'RHWkR>|Jb,-r/@ia0T|Qws<BV=,Wv&4a,;qk@qC_cAlzrK+l)rb92bq;D7is/H-J' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
